# DIRECTORY=kaggle-titanic-ml
# echo $DIRECTORY
# if [ -d $DIRECTORY ]   # for file "if [-f /home/rama/file]" 
# then 
#     echo "dir present"
# else
#     echo "dir not present"
# fi
source kaggle-to-github.sh exercise-missing-values dansbecker/home-data-for-ml-course  housing-pricing