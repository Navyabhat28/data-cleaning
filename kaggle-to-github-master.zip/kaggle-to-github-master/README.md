# kaggle-to-github
A Bash command line which pull your Kaggle kernel and push it to Github repo.
